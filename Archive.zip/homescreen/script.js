const search = document.getElementById("search");

search.focus();

const isValidUrl = urlString => {
  const regex = /.*\.(com|gov|edu|org|run|vc|ly)/;

  return !!regex.test(urlString);
}

const isFullUrl = urlString => {
  var urlPattern = new RegExp('^https?:\\/\\/.*');

  return !!urlPattern.test(urlString);
}

search.addEventListener("keydown", async function(event) {
  const storage = await browser.storage.sync.get({ "shortcuts": {} });

  const text = event.target.innerText.trim();

  const shortcut = storage.shortcuts[text.toLowerCase()];

  console.log(shortcut, isValidUrl(text));

  event.target.style.fontStyle = shortcut ? "italic" : "normal";
  event.target.style.textDecoration = isValidUrl(text) ? "underline" : "initial";
});

search.addEventListener('keydown', async function(event) {
  if (event.key !== 'Enter') return;

  const text = event.target.innerText.trim();

  if (isValidUrl(text)) {
    if (isFullUrl(text)) {
      window.location = text;
    } else {
      window.location = `http://${(encodeURIComponent(text))}`;
    }
    return;
  }

  const storage = await browser.storage.sync.get({ "shortcuts": {} });

  const shortcut = storage.shortcuts[event.target.innerText.toLowerCase().trim()];

  if (shortcut) return window.location = shortcut;

  window.location = `https://google.com/search?q=${encodeURIComponent(text)}`;
})

search.addEventListener('blur', () => search.focus());
